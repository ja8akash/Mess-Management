from django.apps import AppConfig


class ServicesConfig(AppConfig):
    name = 'database'
